﻿using System;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json.Linq;
using Serilog;

namespace MG.ADMaritime.ApiGateway
{
    public class Service
    {
        public string Name { get; set; } 
        public string URL { get; set; }
    }

    public static class OcelotConfiguration
    {
        public static void AddRemoteOcelotConfigurations(this IConfigurationBuilder configurationBuilder, IConfigurationRoot build, IHostEnvironment env)
        {
            Log.Information("Configuring ocelot");
            var services = build.GetSection("Services").Get<Service[]>();
            var client = new HttpClient();
            var fileName = "ocelot.json";
            JArray jRoutes = new JArray();
            JArray jAggregates = new JArray(); 
            foreach (var service in services) 
            {
                try
                {
                    var configUrl = $"{service.URL}/config/{fileName}";
                    Log.Information($"Getting configurations for {service.Name} from {configUrl}");
                    var config = client.GetAsync(configUrl).Result;
                    var json = config.Content.ReadAsStringAsync().Result;
                    Log.Information($"{configUrl} returned {config.StatusCode}{Environment.NewLine}{json}");

                    if (config.IsSuccessStatusCode)
                    {
                        try
                        {
                            var serviceConfig = JObject.Parse(json);
                            if (serviceConfig.GetValue("Routes") is JArray routesArray)
                                foreach (var route in routesArray)
                                    jRoutes.Add(route); 
                            if (serviceConfig.GetValue("Aggregates") is JArray aggregatesArray)
                                foreach (var route in aggregatesArray)
                                    jAggregates.Add(route);
                        }
                        catch (Exception e)
                        {
                            Log.Error($"{configUrl} returned invalid json.");
                        }
                    }
                }
                catch (Exception e)
                {
                    Log.Error(e, "Failed to get ocelot config");
                }

                var jConfig = new JObject
                {
                    {"Routes", jRoutes},
                    {"Aggregates", jAggregates},
                };
                var fullJson = jConfig.ToString();
                var fileProvider = new InMemoryFileProvider(fullJson);
                Log.Information($"Full ocelot config {Environment.NewLine}{fullJson}");
                configurationBuilder.AddJsonFile(fileProvider, "appsettings.json", false, false);
            }
        }
    }
}