using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace MG.ADMaritime.ApiGateway
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseSerilog()
                .ConfigureAppConfiguration((hostingContext, configurationBuilder) =>
                {
#if RELEASE
                    var configurationRoot = configurationBuilder.Build();
                    Log.Logger = new LoggerConfiguration()
                                 .ReadFrom.Configuration(configurationRoot)
                                 .CreateLogger();
                    configurationBuilder.AddRemoteOcelotConfigurations(configurationRoot,hostingContext.HostingEnvironment);
#endif
                })
                .ConfigureWebHostDefaults(webBuilder => { webBuilder.UseStartup<Startup>(); });
    }
}