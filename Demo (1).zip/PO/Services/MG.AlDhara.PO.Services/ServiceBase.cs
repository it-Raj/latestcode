﻿
using System;

using System.Globalization;
using System.Resources;
using System.Text;
using System.Threading;

namespace MG.AlDhara.PO.Services
{
    public class ServiceBase
    {
        protected readonly IUserSession _userSession;

        public ServiceBase(IUserSession userSession)
        {
            _userSession = userSession;
        }

     
        protected string GetUsername()
        {
            return _userSession?.GetUser()?.Name;
        }

        protected void SetCreatedBy(EntityBase entity)
        {
            entity.CreatedBy = GetUsername() ?? "system";
            entity.CreatedDate = DateTime.Now;
        }
       
        protected void SetUpdatedBy(EntityBase entity)
        {
            entity.UpdatedBy = GetUsername() ?? "system";
            entity.UpdatedDate = DateTime.Now;
        }
    }
}
