﻿using System.Threading.Tasks;
using FluentValidation;
using MG.AlDhara.PO.Domain;
using MG.AlDhara.PO.Domain.Entities;
using MG.AlDhara.PO.Domain.Repository;
using MG.AlDhara.PO.Domain.Validators;
using MG.AlDhara.PO.Interfaces;

namespace MG.AlDhara.PO.Services
{
    public class CategoryService: ServiceBase,ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryService(ICategoryRepository categoryRepository,IUserSession userSession):base(userSession)
        {
            _categoryRepository = categoryRepository;
        }

        public async Task<Category> CreateCategory(Category category)
        {
            await new ServiceCategoryValidator().ValidateAndThrowAsync(category);            
            SetCreatedBy(category);
            var result = await _categoryRepository.Add(category);

            await _categoryRepository.CommitChangesAsync();
            //Publish message to service bus if needed

            return result;
        }

        
    }
}