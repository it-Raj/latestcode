﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using MG.ADMaritime.InspectionsAndFines.Domain.Entities;
using MG.ADMaritime.InspectionsAndFines.Domain.Repository;
using Newtonsoft.Json;

namespace MG.ADMaritime.InspectionsAndFines.Services
{
    public static class Extensions
    {
        public static StringContent ToJsonStringContent(this object obj)
        {
            return new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
        }

        // Y Combinator generic implementation
        private delegate Func<A, R> Recursive<A, R>(Recursive<A, R> r);
        private static Func<A, R> Y<A, R>(Func<Func<A, R>, Func<A, R>> f)
        {
            Recursive<A, R> rec = r => a => f(r(r))(a);
            return rec(rec);
        }

        public static IEnumerable<Lookup> Traverse(this IEnumerable<Lookup> source, string userName)
        {
            var traverse = Extensions.Y<IEnumerable<Lookup>, IEnumerable<Lookup>>(f => items =>
            {
                var r = new List<Lookup>(items);
                foreach (var t in r)
                {
                    t.CreatedBy = userName;
                    t.CreatedDate = DateTime.Now;
                }
                r.AddRange(items.SelectMany(i => f(i.Children)));
                return r;
            });

            return traverse(source);
        }

        public async static Task<T> PopulateLookupsAsync<T>(this T source, ILookupRepository lookupRepository)
        {
            foreach (var prop in source.GetType().GetProperties())
            {
                try
                {
                    var type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    if (type == typeof(Lookup))
                    {
                        var lookupId = source.GetType().GetProperty($"{prop.Name}Id", BindingFlags.Instance | BindingFlags.Public | BindingFlags.SetProperty);
                        if (lookupId == null)
                            continue;
                        prop.SetValue(source, await lookupRepository.GetEntity(l => l.Id == lookupId.GetValue(source).ToString()), null);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return source;
        }
    }
}
