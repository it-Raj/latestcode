﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using MG.AlDhara.PO.Domain.DTO;
using MG.AlDhara.PO.Domain.Entities;
using MG.AlDhara.PO.Domain.Repository;
using MG.AlDhara.PO.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace MG.AlDhara.PO.API.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    public class ServiceCategoryController : POBControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly ICategoryService _categoryService;
        private readonly IMapper _mapper;

        public ServiceCategoryController(ILogger<SampleController> logger,ICategoryRepository categoryRepository,
                                         ICategoryService categoryService,
                                         IMapper mapper) : base(logger)
        {
            _categoryRepository = categoryRepository;
            _categoryService = categoryService;
            _mapper = mapper;
        }

        
      

        [HttpPost("")]
        [ProducesResponseType(typeof(ServiceResponse<CategoryDTO>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ServiceResponse<>), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateCategories([FromBody]CategoryDTO category)
        {
            try
            {
                var result = await _categoryService.CreateCategory(_mapper.Map<Category>(category));
                return OkServiceResponse(result);
            }
            catch (ValidationException e)
            {
                return HandleValidationException(e);
            }
        }
    }
}   