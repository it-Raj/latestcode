﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;


namespace MG.AlDhara.PO.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SampleController : POBControllerBase
    {


        public SampleController( ILogger<SampleController> logger) : base(logger)
        {
            
        }

        [HttpGet]
        public IEnumerable<string>  Get()
        {
            return new string[] { "value1", "value2" };
        }
    }
}
