﻿using HealthChecks.UI.Client;
using MassTransit.ExtensionsDependencyInjectionIntegration;
using MG.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using System;
using System.IO;
using MG.AlDhara.PO.API.DependencyConfig;

namespace MG.AlDhara.PO.API
{
    public class Startup
    {
        private readonly IHostEnvironment _hostEnvironment;

        public Startup(IConfiguration configuration, IHostEnvironment hostEnvironment)
        {
            _hostEnvironment = hostEnvironment;
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public virtual void ConfigureServices(IServiceCollection services)
        {
            try
            {
                services.AddHealthChecks();
                services.AddLogs(Configuration);
                services.AddDbContext(Configuration, _hostEnvironment);
                services.AddDapper(Configuration, _hostEnvironment);
                services.AddOptionsBinders(Configuration);
                services.AddControllers().AddNewtonsoftJson(
                                       options =>
                                       {
                                           options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                                           options.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm:ss";
                                           options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                                           options.SerializerSettings.DefaultValueHandling = DefaultValueHandling.Include;
                                           options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                                       });
                services.AddControllers(config => config.ModelBinderProviders.Insert(0, new DataDescriptorModelBinderProvider()));
                services.AddMapper();
                services.AddCoresAllowAll();
                services.AddSwagger();
                services.AddAuth(Configuration);
                services.AddRepositories();
                services.AddHttpClients(Configuration);
                services.AddDataServices();
              //  services.AddCamunda();
                services.AddServiceBus(Configuration, _hostEnvironment, RegisterAdditionalConsumers);


                services.AddControllersWithViews();
                services.AddRazorPages();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                //logger.Log(nameof(Startup), e);
            }
        }

        protected virtual void RegisterAdditionalConsumers(IServiceCollectionConfigurator configurator)
        {
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddSerilog();
            app.UseCors("AllowAllOrigin");
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(env.ContentRootPath, "config")),
                RequestPath = "/config"
            });
            if (env.IsDevelopment()) app.UseDeveloperExceptionPage();

            app.UseAuthentication();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health", new HealthCheckOptions()
                {
                    Predicate = _ => true,
                    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
                });
                endpoints.MapControllers();
            });

            app.UseSwagger()
               .UseSwaggerUI(c => { c.SwaggerEndpoint("v1/swagger.json", "Al Dhara Api"); });
        }
    }
}