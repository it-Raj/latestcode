﻿using MG.AlDhara.POB.Domain.Enums;
using MG.AlDhara.POB.Domain.Extensions;
using MG.AlDhara.POB.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MG.AlDhara.POB.API.Helper
{
    public class HasPermission : AuthorizeAttribute, IAuthorizationFilter
    {
        public string GroupName; 
        public HasPermission(string args)
        {
            GroupName = args;
        }

      //  public string[] Args { get; }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var service = (IHasPermissionService)context.HttpContext.RequestServices.GetService(typeof(IHasPermissionService));
            string name = service.GetGroupName();
            bool Access = false;
            string[] Grouplist = { };
            if (GroupName == UserRoles.Commercial.ToString())
            {
                Grouplist = UserGroup.Commercial.Description().Split(",");
            }
            else if (GroupName == UserRoles.Individual.ToString())
            {
                Grouplist = UserGroup.Individual.Description().Split(",");
            }
            else if (GroupName == UserRoles.Customers.ToString())
            {
                Grouplist = UserGroup.Customer.Description().Split(",");
            }
            else if (GroupName == UserRoles.Agents.ToString())
            {
                Grouplist = UserGroup.Agent.Description().Split(",");
            }
            else if(GroupName== UserRoles.Inspectors.ToString())
            {
                Grouplist = UserGroup.Inspector.Description().Split(",");
            }


           
            foreach (string group in Grouplist)
            {
                if (name.ToLower() == group.ToLower())
                {
                    Access = true;
                    break;
                }
            }
            if (!Access)
            {
                context.Result = new UnauthorizedResult();
            }
        }

    }
}
