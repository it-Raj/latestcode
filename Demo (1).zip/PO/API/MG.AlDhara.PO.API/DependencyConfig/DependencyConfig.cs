﻿using MassTransit;
using MassTransit.ExtensionsDependencyInjectionIntegration;
using MG.AlDhara.DOB.SQL.Data;
using MG.AlDhara.PO.Domain.Repository;
using MG.AlDhara.PO.Interfaces;
using MG.AlDhara.PO.Services;
using MG.AlDhara.PO.SQL.Infrastructure.Repositories;
using MG.AspNetCore.Filter;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MG.AlDhara.PO.API.DependencyConfig
{
    public static class DependencyConfig
    {
        public static void AddHttpClients(this IServiceCollection services, IConfiguration configuration)
        {
            ///services.AddHttpClient<ILookupService, LookupService>((sp, client) => { client.BaseAddress = new Uri(configuration["MasterDataService:MasterDataBaseURL"]); });
            //services.AddHttpClient<IIdentityClient, IdentityClient>((sp, client) => { client.BaseAddress = new Uri(configuration["IdentityService:IdentityBaseURL"]); });
           // services.AddHttpClient<ILicenseAndPermitsClientService, LicenseAndPermitsClientService>((sp, client) => { client.BaseAddress = new Uri(configuration["LicenseAndPermitsService:LicenseAndPermitsBaseURL"]); });
            //services.AddHttpClient<IDocumentManagementClient, DocumentManagementClient>(nameof(DocumentManagementClient),
            //                                                                (sp, config) =>
            //                                                                {
            //                                                                    var options = sp.GetRequiredService<IOptions<DocumentManagementOptions>>();
            //                                                                    config.BaseAddress = new Uri(options.Value.Url);
            //                                                                });
            //services.AddHttpClient<IMpayClient, MpayClient>(nameof(MpayClient),
            //                                                (sp, config) =>
            //                                                {
            //                                                    var options = sp.GetRequiredService<IOptions<MpayOptions>>();
            //                                                    config.BaseAddress = new Uri(options.Value.BaseUrl);
            //                                                });

            //services.AddHttpClient<IRegistrationClient, RegistrationClient>((sp, client) => { client.BaseAddress = new Uri(configuration["RegistrationService:RegistrationBaseURL"]); });

        }


        //public static void AddCamunda(this IServiceCollection services)
        //{
        //    var camundaBuilder =
        //        services.AddCamundaClient((sp) => sp.GetRequiredService<IOptions<CamundaOptions>>().Value);

        //    camundaBuilder.AddWorker<AssignInspectorWorker>(AssignInspectorWorker.Topics);
        //}

        public static void AddRepositories(this IServiceCollection services)
        {

            services.AddScoped<ICategoryRepository, CategoryRepository> ();
            //services.AddScoped<IFineSubmissionDetailRepository, FineSubmissionDetailRepository>();

            var types = Assembly.Load(new AssemblyName("MG.AlDhara.PO.SQL.Infrastructure"))
                                .DefinedTypes
                                .ToList();
            //Key: Repository interface
            //Value: Repository implementation
            var repos = new Dictionary<Type, Type>();
            foreach (var typeInfo in types)
            {
                var repoInterface = typeInfo.ImplementedInterfaces.FirstOrDefault(e => e.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IRepository<>)));
                if (repoInterface == null)
                    continue;

                repos.Add(repoInterface, typeInfo);
            }

            foreach (var repo in repos)
            {
                services.AddScoped(repo.Key, repo.Value);
            }
        }

        public static void AddDataServices(this IServiceCollection services)
        {
            //services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //var context = new CustomAssemblyLoadContext();
            //context.LoadUnmanagedLibrary(Path.Combine(Directory.GetCurrentDirectory(), "libwkhtmltox.dll"));
            //services.AddSingleton(typeof(IConverter), new SynchronizedConverter(new PdfTools()));
            services.AddScoped(typeof(IUnitOfWork), typeof(UnitOfWork));
            services.AddScoped<IUserSession, UserSession>();
            services.AddScoped<ICategoryService, CategoryService>();

        }

        public static void AddOptionsBinders(this IServiceCollection services, IConfiguration configuration)
        {
            //services.Configure<CamundaOptions>(configuration.GetSection("Camunda"));
            //services.AddOptions<FileSizeLimitOption>().Bind(configuration.GetSection(FileSizeLimitOption.SectionName)).ValidateDataAnnotations();
            //services.Configure<DocumentManagementOptions>(configuration.GetSection("DocumentManagement"));
            //services.Configure<MpayOptions>(configuration.GetSection("Mpay"));
            //services.Configure<EndpointsOptions>(configuration.GetSection("Endpoints"));
        }

        public static void AddDbContext(this IServiceCollection services, IConfiguration configuration, IHostEnvironment env)
        {
            var connectionString = configuration.GetConnectionString("ADMTServiceDB");
            services.AddDbContext<AlDharaDbContext>(options =>
            {
                options.EnableSensitiveDataLogging();
                options.UseSqlServer(connectionString, sqlServerOptions => sqlServerOptions.CommandTimeout(90));
            });
        }

        public static void AddDapper(this IServiceCollection services, IConfiguration configuration, IHostEnvironment env)
        {
            var connectionString = configuration.GetConnectionString("ADMTServiceDB");

            Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;

            services.AddTransient<IDbConnection>(c => new SqlConnection(connectionString));
        }

        public static void AddSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                             new OpenApiInfo
                             {
                                 Version = "2.0",
                                 Title = "Al Dhara API",
                                 Description = "Al Dhara service",
                             });

                c.AddSecurityDefinition("Bearer",
                                        new OpenApiSecurityScheme
                                        {
                                            In = ParameterLocation.Header,
                                            Description = "Please enter into field the word 'Bearer' following by space and JWT",
                                            Name = "Authorization",
                                            Type = SecuritySchemeType.ApiKey
                                        });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            In = ParameterLocation.Header,
                            Description = "Please enter into field the word 'Bearer' following by space and JWT",
                            Name = "Authorization",
                            Type = SecuritySchemeType.ApiKey
                        },
                        Enumerable.Empty<string>().ToList()
                    },
                });
            });
        }

        public static void AddAuth(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<HasPermissionFilterOptions>(new HasPermissionFilterOptions("", ""));

            var audienceConfig = configuration.GetSection("Audience");
            var signingKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(audienceConfig["Secret"]));
            var tokenValidationParameters = new TokenValidationParameters
            {
                NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,
                ValidateIssuer = true,
                ValidIssuer = audienceConfig["Iss"],
                ValidateAudience = true,
                ValidAudience = audienceConfig["Aud"],
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,
                RequireExpirationTime = true
            };

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                    .AddJwtBearer(x =>
                    {
                        x.RequireHttpsMetadata = false;
                        x.TokenValidationParameters = tokenValidationParameters;
                    });
        }

        public static void AddLogs(this IServiceCollection services, IConfiguration configurations)
        {
            Log.Logger = new LoggerConfiguration()
                         .ReadFrom.Configuration(configurations)
                         .CreateLogger();
        }


        public static void AddServiceBus(this IServiceCollection services,
                                         IConfiguration configurations,
                                         IHostEnvironment hostEnvironment,
                                         Action<IServiceCollectionConfigurator> registerAdditionalConsumers)
        {
            Log.Information("Configuring RabbitMQ");

            var massTransitConfig = configurations.GetSection("MassTransit");
            var _protocol = massTransitConfig["Protocol"];
            var _rabbitMQHost = massTransitConfig["ClusterUrl"];
            var _rabbitMQUserName = massTransitConfig["UserName"];
            var _rabbitMQPassword = massTransitConfig["Password"];
            var nodes = massTransitConfig.GetSection("Nodes").Get<string[]>();
            services.AddMassTransit(x =>
            {
                //x.AddConsumer<SubmissionTaskCompletedConsumer>();

                x.AddBus(provider => Bus.Factory.CreateUsingRabbitMq(cfg =>
                {
                    var host = cfg.Host(new Uri($"{_protocol}://{_rabbitMQHost}"),
                                        hostConfig =>
                                        {
                                            hostConfig.Username(_rabbitMQUserName);
                                            hostConfig.Password(_rabbitMQPassword);
                                            if (nodes != null && nodes.Any())
                                                hostConfig.UseCluster(e =>
                                                {
                                                    foreach (var node in nodes)
                                                    {
                                                        e.Node(node);
                                                    }
                                                });
                                        });


                    //Save Checklist data , Inspection Result and send customer notification
                    //cfg.ReceiveEndpoint(host,
                    //                   "SVM.SubmissionTaskCompleted.PerformInspectionRequest.INF",
                    //                   ep =>
                    //                   {
                    //                       ep.BindMessageExchanges = false;
                    //                       ep.UseMessageRetry(r => r.Interval(2, 5000));
                    //                       ep.Bind("MG.ServiceManagement:SubmissionTaskCompleted",
                    //                               bconfig =>
                    //                               {
                    //                                   bconfig.ExchangeType = ExchangeType.Topic;
                    //                                   bconfig.Durable = true;
                    //                                   bconfig.RoutingKey = "*.PerformInspectionRequest";
                    //                               });
                    //                       ep.ConfigureConsumer<SubmissionTaskCompletedConsumer>(provider);
                    //                   });








                    //cfg.Publish<CustomerFinesIncurred>(publishConfig => publishConfig.ExchangeType = ExchangeType.Topic);
                    //cfg.Send<CustomerFinesIncurred>(sendConfig => sendConfig.UseRoutingKeyFormatter(y => $"CustomerFinesIncurred"));

                    //cfg.Publish<InspectorAssigned>(publishConfig => publishConfig.ExchangeType = ExchangeType.Topic);
                    //cfg.Send<InspectorAssigned>(sendConfig => sendConfig.UseRoutingKeyFormatter(y => $"InspectorAssigned"));

                    //cfg.Publish<InspectionResultSubmition>(publishConfig => publishConfig.ExchangeType = ExchangeType.Topic);
                    //cfg.Send<InspectionResultSubmition>(sendConfig => sendConfig.UseRoutingKeyFormatter(y => $"InspectionResultSubmition"));
                    services.AddSingleton(c => host);
                }));
            });

            // Start Service Bus
            var busControl = services.BuildServiceProvider()
                                     .GetService<IBusControl>();

            busControl.Start();
        }


        public static void AddMapper(this IServiceCollection services)
        {
            //services.AddAutoMapper(typeof(EntityToDtoMappings));
        }

        public static void AddCoresAllowAll(this IServiceCollection services)
        {
            services.AddCors(c =>
            {
                c.AddPolicy("AllowAllOrigin",
                            options => options.AllowAnyOrigin()
                                              .AllowAnyMethod()
                                              .AllowAnyHeader());
            });
        }
    }
}