﻿using System;
using System.Collections.Generic;
using System.Text;
using MG;


namespace MG.AlDhara.DOB.Domain.Entities
{
    public class EntityBase : MG.EntityBase
    {
        public EntityBase()
        {
            CreatedBy = "system";
            CreatedDate = DateTime.Now;
        }
    }
}
