﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MG.AlDhara.DOB.Domain.Extensions
{
   public static class Extensions
    {
        public static string Description(this Enum enumValue) =>
          enumValue.GetType()
                   .GetMember(enumValue.ToString())
                   .First()
                   .GetCustomAttribute<DescriptionAttribute>()
                   ?.Description;
    }
}
