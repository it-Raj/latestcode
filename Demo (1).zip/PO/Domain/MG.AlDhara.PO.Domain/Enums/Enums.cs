﻿using System.ComponentModel;

namespace MG.AlDhara.DOB.Domain.Enums
{

    public enum UserGroup
    {
        [Description("AlDhara")] Customer,
       
    }
    public enum UserRoles
    {
        [Description("AlDharaUser")] Commercial,
        
    }

    public enum ApplicationType
    {
        [Description("DRAFT")] DRAFT
        
    }
  
 
   
    public enum Languages
    {
        [Description("En")] En,
        [Description("Ar")] Ar
    }
  

 

    public enum LanguageCode
    {
        [Description("Languagecode")] en

    }

    public enum Language
    {
        [Description("en")] en,
        [Description("ar")] ar

    }

}
