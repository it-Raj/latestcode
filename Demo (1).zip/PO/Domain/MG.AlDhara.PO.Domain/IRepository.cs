﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace MG.AlDhara.PO.Domain
{
    public interface IRepository<T> where T : EntityBase
    {
        Task AddRange(params T[] entity);
        Task<T> Add(T entity);
        Task<T> Update(T entity);
        Task UpdateRange(params T[] entity);
        Task Remove(params T[] entities);
        Task<int> CommitChangesAsync();

        Task<IQueryable<T>> Queryable();
        
        Task<T> GetEntity(Expression<Func<T, bool>> filter);
        
        Task<IEnumerable<T>> GetAllAsync();
    }
}