namespace MG
{
    /// <summary>
    /// Marker interface
    /// </summary>
    public interface IEvent
    {
        
    }
}