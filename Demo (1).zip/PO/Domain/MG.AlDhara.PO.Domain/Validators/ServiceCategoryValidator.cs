﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using MG.AlDhara.PO.Domain.Entities;

namespace MG.AlDhara.PO.Domain.Validators
{
    public class ServiceCategoryValidator: AbstractValidator<Category>
    {
        public ServiceCategoryValidator()
        {
            RuleFor(e => e.Name).NotEmpty();
        }
    }
}
