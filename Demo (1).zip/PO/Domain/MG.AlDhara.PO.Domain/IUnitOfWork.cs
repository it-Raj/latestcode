﻿using System.Threading.Tasks;

namespace MG.AlDhara.PO.Domain.SQL.Data
{
    public interface IUnitOfWork
    {
        int Commit();
        Task<int> CommitAsync();
    }
}