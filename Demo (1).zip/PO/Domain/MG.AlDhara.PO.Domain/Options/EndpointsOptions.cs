﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MG.AlDhara.DOB.Domain.Options
{
    public class EndpointsOptions
    {
        public string ServiceBaseGateway { get; set; }
    }
}
