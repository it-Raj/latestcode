﻿using MG.AlDhara.PO.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace MG.AlDhara.PO.Domain.Repository
{
    public interface ICategoryRepository:IRepository<Category>
    {
        Task<IEnumerable<Category>> GetAllByParentAsync(string parentId);
    }
}
