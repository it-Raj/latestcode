﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MG.AlDhara.PO.Domain.Entities
{
    [Table("LOOKUP")]
    public class Lookup:EntityBase
    {
        [Column("TYPE")]
        public string Type { get; set; }

        [Column("NAME")]
        public string Name { get; set; }

        [Column("METADATA")]
        public string MetaData { get; set; }

        
    }
}