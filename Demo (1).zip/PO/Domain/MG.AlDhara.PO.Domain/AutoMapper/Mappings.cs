﻿using AutoMapper;
using System.Text.RegularExpressions;


namespace MG.AlDhara.DOB.Domain.AutoMapper
{
    public class EntityToDtoMappings : Profile
    {
        public EntityToDtoMappings()
        {
            SourceMemberNamingConvention = new UpperCaseUnderscoreNamingConvention();
            DestinationMemberNamingConvention = new PascalCaseNamingConvention();

            
            //CreateMap<Lookup, LookupDTO>().ReverseMap();


        }
    }

    public class DtoToEntityMappings : Profile
    {
        public DtoToEntityMappings()
        {
            SourceMemberNamingConvention = new PascalCaseNamingConvention();
            DestinationMemberNamingConvention = new UpperCaseUnderscoreNamingConvention();
           

           // CreateMap<DocumentDTO, Document>();
        }
    }

    public class UpperCaseUnderscoreNamingConvention : INamingConvention
    {
        public Regex SplittingExpression { get; } = new Regex(@"[\p{Ll}\p{Lu}0-9]+(?=_?)");

        public string SeparatorCharacter { get { return "_"; } }

        public string ReplaceValue(Match match)
        {
            return match.Value.ToUpper();
        }
    }
}