﻿
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;
using MG.AlDhara.DOB.SQL.Data;
using MG.AlDhara.PO.Domain;
using MG.AlDhara.PO.Domain.Entities;
using MG.AlDhara.PO.Domain.Repository;
using MG.AlDhara.PO.Domain.Validators;
using Microsoft.EntityFrameworkCore;

namespace MG.AlDhara.PO.SQL.Infrastructure.Repositories
{
    public class CategoryRepository : HybridRepositoryBase<Category>, ICategoryRepository
    {
        private readonly AlDharaDbContext _dbContext;

        public CategoryRepository(AlDharaDbContext dbContext, IDbConnection dbConnection) : base(dbContext, dbConnection)
        {
            _dbContext = dbContext;
        }

        public Task<IEnumerable<Category>> GetAllByParentAsync(string parentId)
        {
            return DbConnection.QueryAsync<Category>($"Select * from {TableName} where PARENT_ID = @parentId", new {parentId});
        }
    }
}