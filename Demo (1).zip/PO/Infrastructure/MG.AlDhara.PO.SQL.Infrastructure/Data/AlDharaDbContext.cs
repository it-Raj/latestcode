﻿using MG.AlDhara.DOB.Domain.Entities;
using MG.AlDhara.PO.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;

namespace MG.AlDhara.DOB.SQL.Data
{
    public class AlDharaDbContext : DbContext
    {
        public AlDharaDbContext(DbContextOptions<AlDharaDbContext> options) : base(options)
        {

        }
        public virtual DbSet<Lookup> Lookup { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
                if (entityType.ClrType.IsSubclassOf(typeof(EntityBase)))
                    SetTrackingColumnsMapping(modelBuilder, entityType.ClrType);

           

            base.OnModelCreating(modelBuilder);
        }

        /// <summary>
        ///     Sets the CreatedDate, update changes mapping
        /// </summary>
        private void SetTrackingColumnsMapping(ModelBuilder modelBuilder, Type entityType)
        {
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.Id)).HasColumnName("ID").ValueGeneratedOnAdd();
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.CreatedDate)).HasColumnName("CREATED_DATE");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.CreatedBy)).HasColumnName("CREATEDBY");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.UpdatedBy)).HasColumnName("UPDATEDBY");
            modelBuilder.Entity(entityType).Property(nameof(EntityBase.UpdatedDate)).HasColumnName("UPDATED_DATE");
        }
    }
}