﻿using System;
using System.Threading.Tasks;
//using SD.BuildingBlocks.Infrastructure;

namespace MG.AlDhara.DOB.SQL.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AlDharaDbContext dbContext;

        public UnitOfWork(AlDharaDbContext _dbContext)
        {
            dbContext = _dbContext;
        }

        public int AffectedRows { get; private set; }

        public int Commit()
        {
            try
            {
                AffectedRows = dbContext.SaveChanges();
                return AffectedRows;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> CommitAsync()
        {
            try
            {
                AffectedRows = await dbContext.SaveChangesAsync();
                return AffectedRows;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
           
        }
    }
}