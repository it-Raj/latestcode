﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Dapper;
using MG.AlDhara.PO.Domain;
using Microsoft.EntityFrameworkCore;

namespace MG.AlDhara.PO.SQL.Infrastructure
{
    public abstract class HybridRepositoryBase<T> : IRepository<T> where T : EntityBase
    {
        private readonly DbContext _dbContext;
        private readonly IDbConnection _dbConnection;
        private readonly string _tableName;
        private readonly DbSet<T> _dbSet;


        protected HybridRepositoryBase(DbContext dbContext,
                                    IDbConnection dbConnection,
                                    string tableName)
        {
            _dbContext = dbContext;
            _dbConnection = dbConnection;
            _tableName = tableName ?? throw new ArgumentException(nameof(tableName));
            _dbSet = _dbContext.Set<T>();
        }
        protected HybridRepositoryBase(DbContext dbContext,
                                       IDbConnection dbConnection)
        : this(dbContext, dbConnection, typeof(T).Name)
        {
        }

        protected virtual IDbConnection DbConnection => _dbConnection;
        protected virtual string TableName=> _tableName;

        public virtual Task AddRange(params T[] entity)
        {
            _dbSet.AddRange(entity);
            return Task.CompletedTask;
        }

        public virtual Task<T> Add(T entity)
        {
            if(string.IsNullOrEmpty(entity.Id))
                entity.Id = Guid.NewGuid().ToString();
            return Task.FromResult(_dbSet.Add(entity).Entity);
        }

        public virtual Task<T> Update(T entity)
        {
            return Task.FromResult(_dbSet.Update(entity).Entity);
        }

        public virtual Task UpdateRange(params T[] entity)
        {
            _dbSet.UpdateRange(entity);
            return Task.CompletedTask;
        }

        public virtual Task Remove(params T[] entities)
        {
            _dbSet.RemoveRange(entities);
            return Task.CompletedTask;
        }

        public virtual Task<int> CommitChangesAsync()
        {
            return _dbContext.SaveChangesAsync();
        }

        public virtual Task<IQueryable<T>> Queryable()
        {
            return Task.FromResult(_dbSet.AsQueryable());
        }

        public virtual Task<T> GetEntity(Expression<Func<T, bool>> filter)
        {
            return _dbSet.FirstOrDefaultAsync(filter);
        }

        public virtual Task<IEnumerable<T>> GetAllAsync()
        {
            return _dbConnection.QueryAsync<T>($"SELECT * FROM {_tableName}");
        }

        public Task Remove(T entity)
        {
            throw new NotImplementedException();
        }

        public Task RemoveRange(params T[] entities)
        {
            throw new NotImplementedException();
        }
    }
}