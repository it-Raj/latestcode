﻿using System.Threading.Tasks;
using MG.AlDhara.PO.Domain;
using MG.AlDhara.PO.Domain.Entities;

namespace MG.AlDhara.PO.Interfaces
{
    public interface ICategoryService
    {
        Task<Category> CreateCategory(Category category);
    }
}